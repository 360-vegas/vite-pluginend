export default {
  name: '测试插件',
  version: '1.0.0',
  author: '测试作者',
  description: '用于测试安装功能的插件',
  category: '测试',
  mainNav: {
    key: 'test-install',
    title: '测试插件',
    icon: 'Box',
    path: '/test-install'
  },
  subNav: [
    {
      key: 'index',
      title: '主页',
      icon: 'Document',
      path: '/test-install/index'
    },
  ],
  pages: [
    {
      key: 'index',
      title: '主页',
      path: '/test-install/index',
      name: 'test-install-index',
      icon: 'Document',
      description: '主页页面',
      component: () => import('./pages/index.vue')
    },
  ]
}
