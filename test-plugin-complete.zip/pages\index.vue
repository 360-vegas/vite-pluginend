<template>
  <div class="test-install-index-page">
    <h1>主页</h1>
    <p>这是 测试插件 插件的 主页 页面</p>
  </div>
</template>

<script setup lang="ts">
// 主页页面逻辑
</script>

<style scoped>
.test-install-index-page {
  padding: 20px;
}
</style>
